ResourceManager Class

Manages resources and processes for deadlock detection and prevention.

Public Methods:
void addProcess(const Process& process)
Adds a new process to the system.
Parameters:
process - A Process object containing process ID, priority, allocated resources, and maximum resource needs.
void addResource(const Resource& resource)
Adds a new resource to the system.
Parameters:
resource - A Resource object containing resource ID, total available, and currently available units.
bool requestResource(int processId, int resourceId, int count)
Handles resource requests from processes.
Parameters:
processId - ID of the process requesting the resource.
resourceId - ID of the requested resource.
count - Number of resource units requested.
Returns:
true if the resource request is granted; otherwise, false.
void releaseResource(int processId, int resourceId, int count)
Handles resource release by processes.
Parameters:
processId - ID of the process releasing the resource.
resourceId - ID of the released resource.
count - Number of resource units released.
void displayState()
Displays the current resource allocation state.
BankerAlgorithm Class

Implements the Banker's algorithm for deadlock avoidance.

Public Methods:
bool isSafeState(const ResourceManager& rm)
Checks if the system is in a safe state.
Parameters:
rm - The ResourceManager instance containing the system state.
Returns:
true if the system is in a safe state; otherwise, false.
DeadlockDetection Class

Detects and handles deadlocks in the system.

Public Methods:
bool detectDeadlock(const ResourceManager& rm, std::vector<int>& deadlockedProcesses)
Detects deadlocks in the system and lists the affected processes.
Parameters:
rm - The ResourceManager instance containing the system state.
deadlockedProcesses - A vector to store IDs of deadlocked processes.
Returns:
true if a deadlock is detected; otherwise, false.