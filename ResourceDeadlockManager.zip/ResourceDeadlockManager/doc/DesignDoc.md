Overview

The Resource Deadlock Manager is a system to manage resources and processes, ensuring that deadlocks are detected, avoided, and resolved. The project incorporates a resource allocation graph, Banker's algorithm, and deadlock detection techniques.

Key Components

ResourceManager:
Maintains the state of all resources and processes.
Provides methods for resource allocation, release, and state visualization.
BankerAlgorithm:
Implements Banker's algorithm to determine if the system remains in a safe state after a resource allocation.
DeadlockDetection:
Detects cycles in the resource allocation graph to identify deadlocks.
Architecture

Classes:
ResourceManager: Core class for managing resources and processes.
BankerAlgorithm: Used for safe state checks.
DeadlockDetection: Used for deadlock identification.
Interactions:
The ResourceManager tracks the state of resources and processes.
When a resource request is made, the BankerAlgorithm checks if the allocation is safe.
Periodically or on-demand, DeadlockDetection identifies deadlocked processes.
Data Structures

Processes:
Represented as a Process object with fields for allocated and maximum resource needs.
Resources:
Represented as a Resource object with fields for total and available units.