Metrics

Time Complexity:
Resource allocation: O(P × R), where P is the number of processes and R is the number of resources.
Deadlock detection: O(P × R) in the worst case.
Space Complexity:
Uses O(P + R) space to store resource and process states.
Performance Observations

Tested with up to 100 processes and 50 resources.
Resource allocation completed in under 1 second for all test cases.
Deadlock detection remained efficient with a response time under 2 seconds.
Optimization Opportunities

Improve deadlock detection by using adjacency matrices for faster graph traversal.
Parallelize resource allocation for systems with a large number of resources.