Setup

Compile the program using:
make
Run the program:
./resource_manager
Features

Add Resources:
Resources are added with their ID, total units, and available units.
Example: {1, 5, 5} adds a resource with ID 1, total 5, and 5 available units.
Add Processes:
Processes are added with their ID, priority, allocated resources, and maximum needs.
Example: {1, 1, {{1, 0}, {2, 0}}, {{1, 3}, {2, 2}}} adds a process with ID 1, priority 1.
Request Resources:
Processes request resources using their ID, resource ID, and units requested.
Example: requestResource(1, 1, 2) allows process 1 to request 2 units of resource 1.
Release Resources:
Processes release resources using their ID, resource ID, and units released.
Example: releaseResource(1, 1, 2) releases 2 units of resource 1 from process 1.
Check Deadlocks:
The program automatically checks for deadlocks and displays the affected processes if any.
Safe State Check:
Banker's algorithm ensures resources are allocated only if the system remains in a safe state.