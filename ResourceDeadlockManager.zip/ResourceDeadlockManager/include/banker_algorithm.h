#ifndef BANKER_ALGORITHM_H
#define BANKER_ALGORITHM_H

#include "resource_manager.h"

class BankerAlgorithm {
public:
    static bool isSafeState(const ResourceManager& rm);
};

#endif
