#ifndef DEADLOCK_DETECTION_H
#define DEADLOCK_DETECTION_H

#include "resource_manager.h"
#include <map>
#include <set>
#include <iostream>

class DeadlockDetection {
public:
    static bool detectDeadlock(const ResourceManager& rm, std::vector<int>& deadlockedProcesses);
private:
    static bool detectCycle(int pid, const std::map<int, Process>& processes, std::map<int,int>& available, std::set<int>& path, std::set<int>& visited);
};

#endif
