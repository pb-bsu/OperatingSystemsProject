#ifndef RESOURCE_MANAGER_H
#define RESOURCE_MANAGER_H

#include <vector>
#include <map>
#include <string>

struct Process {
    int id;
    int priority;
    std::map<int, int> allocated; // ResourceType -> Count
    std::map<int, int> maximum;   // ResourceType -> Count
};

struct Resource {
    int id;
    int total;
    int available;
};

class ResourceManager {
public:
    void addProcess(const Process& process);
    void addResource(const Resource& resource);
    bool requestResource(int processId, int resourceId, int count);
    void releaseResource(int processId, int resourceId, int count);
    void displayState();

    std::map<int, Resource> getResources() const;
    std::map<int, Process> getProcesses() const;


private:
    std::map<int, Process> processes;
    std::map<int, Resource> resources;
};

#endif
