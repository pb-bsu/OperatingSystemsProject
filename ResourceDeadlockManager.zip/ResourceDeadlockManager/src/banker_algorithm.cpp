#include "banker_algorithm.h"

bool BankerAlgorithm::isSafeState(const ResourceManager& rm) {
    auto resources = rm.getResources();
    auto processes = rm.getProcesses();

    std::map<int, int> available;
    for (const auto& [rid, resource] : resources) {
        available[rid] = resource.available;
    }

    return true;
}
