#include "deadlock_detection.h"
#include <iostream>
#include <set>

bool DeadlockDetection::detectDeadlock(const ResourceManager& rm, std::vector<int>& deadlockedProcesses) {
    auto processes = rm.getProcesses();
    auto resources = rm.getResources();

    std::map<int, int> available;
    for (const auto& [rid, resource] : resources) {
        available[rid] = resource.available;
    }

    std::set<int> visited;

    for (const auto& [pid, _] : processes) {
        if (visited.count(pid)) continue;

        std::set<int> path;
        bool deadlocked = detectCycle(pid, processes, available, path, visited);

        if (deadlocked) {
            deadlockedProcesses.insert(deadlockedProcesses.end(), path.begin(), path.end());
        }
    }

    if (!deadlockedProcesses.empty()) {
        std::cout << "Deadlock detected among processes: ";
        for (int pid : deadlockedProcesses) {
            std::cout << pid << " ";
        }
        std::cout << "\n";
        return true;
    }

    std::cout << "No deadlock detected.\n";
    return false;
}

bool DeadlockDetection::detectCycle(int pid, const std::map<int, Process>& processes,
                                    std::map<int, int>& available,
                                    std::set<int>& path, std::set<int>& visited) {
    if (path.count(pid)) return true; // Cycle detected

    path.insert(pid);
    visited.insert(pid);

    const auto& process = processes.at(pid);
    for (const auto& [rid, maxNeed] : process.maximum) {
        if (available[rid] < maxNeed) {
            for (const auto& [neighborPid, _] : processes) {
                if (detectCycle(neighborPid, processes, available, path, visited)) {
                    return true;
                }
            }
        }
    }

    path.erase(pid);
    return false;
}
