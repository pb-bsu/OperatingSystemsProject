#include "resource_manager.h"
#include "banker_algorithm.h"
#include "deadlock_detection.h"
#include <iostream>

int main() {
    ResourceManager manager;

    manager.addResource({1, 5, 5}); // Resource ID 1, Total 5
    manager.addResource({2, 3, 3}); // Resource ID 2, Total 3

    manager.addProcess({1, 1, {{1, 0}, {2, 0}}, {{1, 3}, {2, 2}}}); // Process ID 1
    manager.addProcess({2, 2, {{1, 0}, {2, 0}}, {{1, 2}, {2, 2}}}); // Process ID 2

    manager.requestResource(1, 1, 2);
    manager.requestResource(2, 2, 1);

    manager.displayState();

    BankerAlgorithm banker;
    if (banker.isSafeState(manager)) {
        std::cout << "The system is in a safe state.\n";
    } else {
        std::cout << "The system is in an unsafe state.\n";
    }

    return 0;
}
