#include "resource_manager.h"
#include <iostream>

void ResourceManager::addProcess(const Process& process) {
    processes[process.id] = process;
}

void ResourceManager::addResource(const Resource& resource) {
    resources[resource.id] = resource;
}

bool ResourceManager::requestResource(int processId, int resourceId, int count) {
    if (processes.find(processId) == processes.end() || resources.find(resourceId) == resources.end()) {
        return false;
    }

    Resource& resource = resources[resourceId];
    Process& process = processes[processId];

    if (resource.available < count) {
        return false;
    }

    resource.available -= count;
    process.allocated[resourceId] += count;
    return true;
}

void ResourceManager::releaseResource(int processId, int resourceId, int count) {
    if (processes.find(processId) == processes.end() || resources.find(resourceId) == resources.end()) {
        return;
    }

    Resource& resource = resources[resourceId];
    Process& process = processes[processId];

    resource.available += count;
    process.allocated[resourceId] -= count;
}

void ResourceManager::displayState() {
    std::cout << "Resources:\n";
    for (const auto& [id, resource] : resources) {
        std::cout << "ID: " << id << ", Total: " << resource.total << ", Available: " << resource.available << "\n";
    }
    std::cout << "Processes:\n";
    for (const auto& [id, process] : processes) {
        std::cout << "ID: " << id << ", Priority: " << process.priority << "\n";
    }
}

std::map<int, Resource> ResourceManager::getResources() const {
    return resources;
}

std::map<int, Process> ResourceManager::getProcesses() const {
    return processes;
}
