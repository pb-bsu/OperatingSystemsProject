#include <gtest/gtest.h>
#include "resource_manager.h"
#include "banker_algorithm.h"
#include "deadlock_detection.h"

TEST(ResourceManagerTest, AddAndRequestResources) {
    ResourceManager rm;

    // Add resources
    rm.addResource({1, 10, 10});
    rm.addResource({2, 5, 5});

    // Add processes
    rm.addProcess({1, 1, {{1, 0}, {2, 0}}, {{1, 7}, {2, 5}}});
    rm.addProcess({2, 2, {{1, 0}, {2, 0}}, {{1, 3}, {2, 2}}});

    // Request resources
    ASSERT_TRUE(rm.requestResource(1, 1, 5)); // Successful
    ASSERT_FALSE(rm.requestResource(1, 2, 6)); // Exceeds available resources

    rm.releaseResource(1, 1, 5); // Release resources
    ASSERT_TRUE(rm.requestResource(1, 1, 7)); // Now successful
}

TEST(BankerAlgorithmTest, SafeStateChecking) {
    ResourceManager rm;

    // Add resources
    rm.addResource({1, 10, 10});
    rm.addResource({2, 5, 5});

    // Add processes
    rm.addProcess({1, 1, {{1, 0}, {2, 0}}, {{1, 7}, {2, 5}}});
    rm.addProcess({2, 2, {{1, 0}, {2, 0}}, {{1, 3}, {2, 2}}});

    // Request resources
    rm.requestResource(1, 1, 5);
    rm.requestResource(2, 2, 2);

    ASSERT_TRUE(BankerAlgorithm::isSafeState(rm)); // Safe state

    rm.requestResource(1, 2, 3);
    ASSERT_FALSE(BankerAlgorithm::isSafeState(rm)); // Unsafe state
}

TEST(DeadlockDetectionTest, DetectDeadlock) {
    ResourceManager rm;

    // Add resources
    rm.addResource({1, 5, 5});
    rm.addResource({2, 5, 5});

    // Add processes
    rm.addProcess({1, 1, {{1, 2}, {2, 0}}, {{1, 3}, {2, 2}}});
    rm.addProcess({2, 2, {{1, 0}, {2, 3}}, {{1, 2}, {2, 3}}});

    // Request resources leading to a deadlock
    rm.requestResource(1, 2, 2);
    rm.requestResource(2, 1, 2);

    std::vector<int> deadlockedProcesses;
    ASSERT_TRUE(DeadlockDetection::detectDeadlock(rm, deadlockedProcesses));
    ASSERT_EQ(deadlockedProcesses.size(), 2); // Both processes in deadlock
}
